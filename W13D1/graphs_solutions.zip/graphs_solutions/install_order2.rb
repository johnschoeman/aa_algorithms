# In this version of the problem, all packages will be listed, including
# independent ones (independant packages have nil or no value for their
# dependencies), but the package ids may not be numbers.
def install_order2(arr)

end

# arr = [[3, 1], [2, 1], [6, 5], [3, 6], [3, 2], [4, 3], [9, 1], [1, nil], [5, nil]]
# arr2 = [['a', 'b'], ['c', 'b'], ['d', 'a'], ['b'], ['e', 'd']]
#
# p install_order2(arr)
# p install_order2(arr2)
