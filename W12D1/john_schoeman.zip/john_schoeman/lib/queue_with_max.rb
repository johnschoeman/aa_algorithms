require 'byebug'
# Implement a queue with #enqueue and #dequeue, as well as a #max API,
# a method which returns the maximum element still in the queue. This
# is trivial to do by spending O(n) time upon dequeuing.
# Can you do it in O(1) amortized? Maybe use an auxiliary storage structure?

# Use your RingBuffer to achieve optimal shifts! Write any additional
# methods you need.

require_relative 'ring_buffer'

class QueueWithMax
  attr_accessor :max_store, :store

  def initialize
    @max_store = RingBuffer.new
    @store = RingBuffer.new
  end

  def enqueue(val)
    if @max_store.length == 0 || val >= @max_store[0]
      @max_store.unshift(val)
    end
    @store.unshift(val)
  end

  def dequeue
    result = @store.pop
    if @max_store.length != 0 && result == @max_store[0]
      @max_store.shift
    elsif @max_store.length != 0 && result == @max_store[@max_store.length - 1]
      @max_store.pop
    end
    result
  end

  # O(1) amortizied.
  # the stragegy here is to store the current max value in a ring buffer, if an enque results in a new max you'll unshift it on.
  # you return the top of the stack to find the current highest value seen.
  # poping off past max values from the bottom of the stack as you deque works so long as new enqued numbers are not smaller than the current max, less than ideal.
  # for the case where enequed numbers are smaller, your max store ringbuffer will eventually run out of numbers to pop during a dequeue
  # if you ever run out of numbers, you recreate the max_store from the current store in the same process.  this is O(n).
  # however this will buy you n 'free' deques with the accurate max value.
  
  def max
    if @max_store.length != 0
      @max_store[0]
    else
      new_queue = QueueWithMax.new
      (0...self.store.length).each do |i|
        new_queue.enqueue(self.store[i])
      end
      @max_store = new_queue.max_store
      @max_store[0]
    end
  end

  def length
    @store.length
  end

end
